import type { LoaderFunction } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import passport from "passport";

export let loader: LoaderFunction = async ({ request }) => {
  return passport.authenticate("google", {
    scope: ["profile", "email"],
  })(request);
};
