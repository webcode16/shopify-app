import type { LoaderFunction } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import passport from "passport";

export let loader: LoaderFunction = async ({ request }) => {
  return new Promise((resolve, reject) => {
    passport.authenticate("google", (err: Error | null, user: Express.User | false | null) => {
      if (err || !user) {
        return resolve(redirect("/login?error=true"));
      }
      // Set a session cookie, or your logic
      // TODO: You can store user in DB here
      return resolve(redirect("/dashboard"));
    })(request);
  });
};
