// public/social-login.ts

declare global {
    interface Window {
      google: any;
      handleGoogleLogin: () => void;
    }
  }
  
  window.addEventListener('load', () => {
    // Load Google SDK
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);
  
    // Expose the login function globally
    window.handleGoogleLogin = () => {
      if (!window.google || !window.google.accounts) {
        console.error('Google SDK not loaded.');
        return;
      }
  
      window.google.accounts.id.initialize({
        client_id: 'YOUR_GOOGLE_CLIENT_ID', // <-- Replace this
        callback: handleCredentialResponse,
      });
  
      window.google.accounts.id.prompt();
    };
  
    function handleCredentialResponse(response: any) {
      console.log('Google token:', response.credential);
  
      // TODO: Send to your backend to validate and authenticate
      fetch('https://your-app.com/api/social-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token: response.credential }),
      }).then((res) => {
        console.log('Server response:', res);
      });
    }
  });
  
  export {};
  